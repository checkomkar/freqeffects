jQuery(document).ready(function($) {
    var upgrade_notice = '<a class="upgrade-pro" target="_blank" href="https://accesspressthemes.com/wordpress-themes/accesspress-store-pro/">UPGRADE TO ACCESSPRESS STORE PRO</a>';
    upgrade_notice += '<a class="upgrade-pro" target="_blank" href="http://accesspressthemes.com/theme-demos/?theme=accesspress-store-pro">ACCESSPRESS STORE PRO DEMO</a>';
    jQuery('#customize-info .preview-notice').append(upgrade_notice);
});